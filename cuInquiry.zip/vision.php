<?php include "include/header.php"; ?>

<div>
    <br>
    <center>
        <h1>Vision of Pracharwall</h1>
    </center>
    <br>

    <div class="container">

    <div class="d-flex"><i class="bi bi-check2-all mx-2"></i> <p>To be a global leader in the Pracharwall industry, delivering innovative and impactful campaigns that drive business growth for our clients.</p></div>
    <div class="d-flex"><i class="bi bi-check2-all mx-2"></i> <p>To create a powerful and lactating connection between brands and their target audience, leveraging creativity technologies and strategic insights.</p></div>
    <div class="d-flex"><i class="bi bi-check2-all mx-2"></i> <p>To be recognized as a trusted partner for our clients, providing them with cutting-edge Pracharwall solutions tailored to their unique needs.</p></div>
    <div class="d-flex"><i class="bi bi-check2-all mx-2"></i> <p>To constantly push the boundaries of creativity and innovation, setting nes standards in the Pracharwall industry.</p></div>
    <div class="d-flex"><i class="bi bi-check2-all mx-2"></i> <p>To become a driving force in shaping the future of Pracharwall by embracing emerging technologies and trends.</p></div>
    <div class="d-flex"><i class="bi bi-check2-all mx-2"></i> <p>To foster a culture of collaboration and diversity, bringing together talented individuals from different backgrounds to create exceptional Pracharwall campaigns</p></div>
    <div class="d-flex"><i class="bi bi-check2-all mx-2"></i> <p>To continuously adapt and evolve in response to the ever-changing media landscape and consumer behavior.</p></div>
    <div class="d-flex"><i class="bi bi-check2-all mx-2"></i> <p>To maintain the highest ethical standards in our Pracharwall practices, ensuring transparency, honesty and respect for consumer privacy.</p></div>


    </div>
</div>

<?php include "include/footer.php"; ?>