<?php
include "include/header.php";
?>

<div class="container">
    <center class="pt-2">
        <h2 class="h2">How to Register Your Wall</h2>
    </center>
    <hr>


    <img src="assets/img/howto.png" class="img-fluid mb-5" />

</div>

<?php include "include/footer.php"; ?>





<!-- <div class="container mt-4 w-50 border p-4 border-secondary rounded">
    <form action="admin/action/register_wall_post.php" method="post" enctype="multipart/form-data"> 
        <div class="row mb-4">
            <div class="col">
                <div class="form-outline">
                    <input type="text" name="serviceName" class="form-control" />
                    <label class="form-label" for="ser-name">Service Name</label>
                </div>
            </div>
            <div class="col">
                <div class="form-outline">
                    <input type="text" name="serviceType" class="form-control" />
                    <label class="form-label" for="ser-type">Service Type</label>
                </div>
            </div>
        </div>

        <div class="form-outline mb-4">
            <input type="file" name="uploaded_file" class="form-control" />
            <label class="form-label" for="ser-file">Service Demo File</label>
        </div>

        <div class="form-outline mb-4">
            <input type="email" name="email" class="form-control" />
            <label class="form-label" for="form6Example5">Email</label>
        </div>

        <div class="row mb-4">
            <div class="col">
                <div class="form-outline">
                    <input type="text" name="city" class="form-control" />
                    <label class="form-label" for="city">City</label>
                </div>
            </div>

            <div class="col">
                <div class="form-outline">
                    <input type="number" name="mobile" class="form-control" />
                    <label class="form-label" for="form6Example6">Mobile No.</label>
                </div>
            </div>
        </div>

        <div class="form-outline mb-4">
            <textarea class="form-control" name="description" rows="4"></textarea>
            <label class="form-label" for="form6Example7">Service Description</label>
        </div>

        <button type="submit" name="submit" class="btn btn-primary btn-block mb-4">Register Wall</button>
    </form>
</div> -->